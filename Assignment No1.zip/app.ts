let message = "Hello world!"

console.log("message");

let firstName: string = "hello eric!";
console.log(firstName);
