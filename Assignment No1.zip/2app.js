"use strict";
let firstname = "eric!";
console.log(firstname);
