"use strict";
let afirstName = "eric";
console.log(`lowercase: ${afirstName.toLowerCase()}`);
