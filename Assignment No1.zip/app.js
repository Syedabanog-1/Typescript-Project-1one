"use strict";
let message = "Hello world!";
console.log("message");
let firstName = "hello eric!";
console.log(firstName);
