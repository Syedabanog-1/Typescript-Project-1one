let firstname = "eric!";
console.log(firstname);

