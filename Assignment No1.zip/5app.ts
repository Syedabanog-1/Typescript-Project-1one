let famous_person: string = "Albert Einstien";
//console.log(`lowercase: ${afirstName.toLowerCase()}`);

//console.log("Albert eienstein once said, learn from yersterday leave in today hope for tommorow and the best thing that do not stop questioning");



let new_message = "Albert eienstein once said, learn from yersterday leave in today hope for tommorow and the best thing that do not stop questioning";

console.log(famous_person);
console.log(new_message);

//let firstName: string = "hello eric!";

