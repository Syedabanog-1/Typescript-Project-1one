let afirstName: string = "eric";
console.log(`lowercase: ${afirstName.toLowerCase()}`);
