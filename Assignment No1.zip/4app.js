"use strict";
console.log("Albert eienstein once said, learn from yersterday leave in today hope for tommorow and the best thing that do not stop questioning");
